$(document).ready(function () {
  // Gérer le clic sur le bouton Catégories
  $('.categories-button').click(function () {
      $('.sidebar').toggle() // Affiche ou cache la barre latérale des catégories
  })
})